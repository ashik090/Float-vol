package com.ashik.floatvol

import android.content.Context
import android.content.SharedPreferences

class PrefsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("floatvol_prefs", Context.MODE_PRIVATE)

    var isServiceEnabled: Boolean
        get() = prefs.getBoolean("service_enabled", false)
        set(value) = prefs.edit().putBoolean("service_enabled", value).apply()

    var isPositionLocked: Boolean
        get() = prefs.getBoolean("position_locked", false)
        set(value) = prefs.edit().putBoolean("position_locked", value).apply()

    var isEdgeSnapEnabled: Boolean
        get() = prefs.getBoolean("edge_snap", true)
        set(value) = prefs.edit().putBoolean("edge_snap", value).apply()

    var isAutoDimEnabled: Boolean
        get() = prefs.getBoolean("auto_dim", true)
        set(value) = prefs.edit().putBoolean("auto_dim", value).apply()

    var isSwipeVolumeEnabled: Boolean
        get() = prefs.getBoolean("swipe_volume", true)
        set(value) = prefs.edit().putBoolean("swipe_volume", value).apply()

    var isHapticEnabled: Boolean
        get() = prefs.getBoolean("haptic_enabled", true)
        set(value) = prefs.edit().putBoolean("haptic_enabled", value).apply()

    // true = Double-click takes Stealth Screenshot (hides button completely)
    // false = Double-click toggles Media Mute
    var isDoubleTapScreenshot: Boolean
        get() = prefs.getBoolean("double_tap_screenshot", true)
        set(value) = prefs.edit().putBoolean("double_tap_screenshot", value).apply()

    var buttonSizeDp: Int
        get() = prefs.getInt("button_size_dp", 52)
        set(value) = prefs.edit().putInt("button_size_dp", value).apply()

    var idleOpacityPercent: Int
        get() = prefs.getInt("idle_opacity", 40)
        set(value) = prefs.edit().putInt("idle_opacity", value).apply()

    var savedX: Int
        get() = prefs.getInt("saved_x", 0)
        set(value) = prefs.edit().putInt("saved_x", value).apply()

    var savedY: Int
        get() = prefs.getInt("saved_y", 300)
        set(value) = prefs.edit().putInt("saved_y", value).apply()
}
