package com.ashik.floatvol

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class FloatingVolumeService : Service() {

    companion object {
        const val ACTION_REFRESH_PREFS = "com.ashik.floatvol.ACTION_REFRESH_PREFS"
        const val ACTION_STOP_SERVICE = "com.ashik.floatvol.ACTION_STOP_SERVICE"
        private const val CHANNEL_ID = "floatvol_overlay_channel"
        private const val NOTIFICATION_ID = 1001
        private const val AUTO_DIM_DELAY_MS = 3000L
        private const val DOUBLE_TAP_WINDOW_MS = 240L
        private const val STEALTH_RESTORE_DELAY_MS = 650L
    }

    private lateinit var windowManager: WindowManager
    private lateinit var audioManager: AudioManager
    private lateinit var prefs: PrefsManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var floatingBubbleView: View? = null
    private var bubbleIconText: TextView? = null
    private var expandedPanelView: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private val autoDimRunnable = Runnable {
        if (prefs.isAutoDimEnabled && expandedPanelView == null) {
            floatingBubbleView?.animate()
                ?.alpha(prefs.idleOpacityPercent / 100f)
                ?.setDuration(350)
                ?.start()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        prefs = PrefsManager(this)

        startMinimalForegroundNotification()
        createFloatingBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                prefs.isServiceEnabled = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH_PREFS -> {
                applyDynamicPreferences()
            }
        }
        return START_STICKY
    }

    private fun startMinimalForegroundNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Volume Service",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Keeps the ultra-light floating volume button active"
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingVolumeService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle("FloatVol Active")
            .setContentText("Single tap: Volume UI • Double tap: Stealth Screenshot")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun createFloatingBubble() {
        val sizePx = dpToPx(prefs.buttonSizeDp)

        val container = FrameLayout(this)
        val bgDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E61E293B"))
            setStroke(dpToPx(2), Color.parseColor("#38BDF8"))
        }
        container.background = bgDrawable
        container.elevation = dpToPx(8).toFloat()

        val iconLabel = TextView(this).apply {
            text = getVolumeStateEmoji()
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        bubbleIconText = iconLabel
        container.addView(
            iconLabel,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.savedX
            y = prefs.savedY
        }

        setupTouchInteractions(container)
        windowManager.addView(container, bubbleParams)
        floatingBubbleView = container
        scheduleAutoDim()
    }

    private fun setupTouchInteractions(view: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var tapCount = 0
        var isLongPressTriggered = false
        var isSwipingVolume = false
        var swipeAccumulatedDy = 0f

        val singleTapRunnable = Runnable {
            if (tapCount == 1) {
                openNativeSystemVolumeUI()
            }
            tapCount = 0
        }

        val longPressRunnable = Runnable {
            isLongPressTriggered = true
            tapCount = 0
            mainHandler.removeCallbacks(singleTapRunnable)
            triggerHaptic()
            toggleExpandedQuickPanel()
        }

        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    wakeUpBubbleOpacity()
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isLongPressTriggered = false
                    isSwipingVolume = false
                    swipeAccumulatedDy = 0f
                    mainHandler.postDelayed(longPressRunnable, 480L)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY

                    if (abs(dx) > dpToPx(8) || abs(dy) > dpToPx(8)) {
                        mainHandler.removeCallbacks(longPressRunnable)
                    }

                    if (prefs.isPositionLocked && prefs.isSwipeVolumeEnabled) {
                        val stepThreshold = dpToPx(22)
                        val deltaY = event.rawY - initialTouchY - swipeAccumulatedDy
                        if (abs(deltaY) >= stepThreshold) {
                            isSwipingVolume = true
                            tapCount = 0
                            mainHandler.removeCallbacks(singleTapRunnable)
                            val direction = if (deltaY < 0) {
                                AudioManager.ADJUST_RAISE
                            } else {
                                AudioManager.ADJUST_LOWER
                            }
                            audioManager.adjustSuggestedStreamVolume(
                                direction,
                                AudioManager.USE_DEFAULT_STREAM_TYPE,
                                AudioManager.FLAG_SHOW_UI
                            )
                            triggerHaptic()
                            updateBubbleIcon()
                            swipeAccumulatedDy += deltaY
                        }
                    } else if (!prefs.isPositionLocked && !isLongPressTriggered) {
                        bubbleParams.x = initialX + dx.toInt()
                        bubbleParams.y = initialY + dy.toInt()
                        floatingBubbleView?.let { windowManager.updateViewLayout(it, bubbleParams) }
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    val totalMove = abs(event.rawX - initialTouchX) + abs(event.rawY - initialTouchY)

                    if (!isLongPressTriggered && !isSwipingVolume && totalMove < dpToPx(10)) {
                        tapCount++
                        if (tapCount == 1) {
                            // Debounce 240ms to distinguish Single Tap from Double Tap
                            mainHandler.postDelayed(singleTapRunnable, DOUBLE_TAP_WINDOW_MS)
                        } else if (tapCount >= 2) {
                            mainHandler.removeCallbacks(singleTapRunnable)
                            tapCount = 0
                            if (prefs.isDoubleTapScreenshot) {
                                performStealthScreenshot()
                            } else {
                                toggleMediaMute()
                            }
                        }
                    } else if (!prefs.isPositionLocked) {
                        if (prefs.isEdgeSnapEnabled) {
                            snapToNearestHorizontalEdge()
                        } else {
                            prefs.savedX = bubbleParams.x
                            prefs.savedY = bubbleParams.y
                        }
                    }

                    scheduleAutoDim()
                    true
                }
                else -> false
            }
        }
    }

    /**
     * Core Function: Triggers Android's built-in native hardware volume control slider UI.
     */
    private fun openNativeSystemVolumeUI() {
        triggerHaptic()
        audioManager.adjustSuggestedStreamVolume(
            AudioManager.ADJUST_SAME,
            AudioManager.USE_DEFAULT_STREAM_TYPE,
            AudioManager.FLAG_SHOW_UI
        )
        updateBubbleIcon()
    }

    /**
     * New v1.1 Feature: Double-Click Stealth Screenshot.
     * Hides the floating button & expanded panel BEFORE the frame buffer is captured,
     * waits for Choreographer next frame + compositor sync, takes the system screenshot,
     * and smoothly restores the floating button afterward.
     */
    private fun performStealthScreenshot() {
        triggerHaptic()

        if (FloatVolAccessibilityService.instance == null) {
            Toast.makeText(
                this,
                "Enable 'FloatVol Stealth Screenshot' in Accessibility Settings first",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            return
        }

        // 1. Close expanded hub if open and make the floating button completely invisible
        closeExpandedQuickPanel()
        val bubble = floatingBubbleView ?: return
        bubble.visibility = View.GONE

        // 2. Wait for the display compositor to render the clean frame without the button
        Choreographer.getInstance().postFrameCallback {
            mainHandler.postDelayed({
                FloatVolAccessibilityService.triggerSystemScreenshot()

                // 3. Restore the floating button after screenshot capture completes
                mainHandler.postDelayed({
                    bubble.alpha = 0f
                    bubble.visibility = View.VISIBLE
                    bubble.animate().alpha(1f).setDuration(180).withEndAction {
                        scheduleAutoDim()
                    }.start()
                }, STEALTH_RESTORE_DELAY_MS)
            }, 45L)
        }
    }

    /**
     * Optional Double-tap action: Media Mute toggle.
     */
    private fun toggleMediaMute() {
        triggerHaptic()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioManager.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_TOGGLE_MUTE,
                AudioManager.FLAG_SHOW_UI
            )
        }
        updateBubbleIcon()
    }

    private fun toggleExpandedQuickPanel() {
        if (expandedPanelView != null) {
            closeExpandedQuickPanel()
            return
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(14))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(18).toFloat()
                setColor(Color.parseColor("#F20F172A"))
                setStroke(dpToPx(1), Color.parseColor("#3338BDF8"))
            }
        }

        val titleRow = TextView(this).apply {
            text = "FloatVol Quick Hub"
            textSize = 14f
            setTextColor(Color.parseColor("#38BDF8"))
            setPadding(0, 0, 0, dpToPx(8))
        }
        panel.addView(titleRow)

        panel.addView(buildStreamSlider("Media", AudioManager.STREAM_MUSIC))
        panel.addView(buildStreamSlider("Ring", AudioManager.STREAM_RING))
        panel.addView(buildStreamSlider("Alarm", AudioManager.STREAM_ALARM))

        val actionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(10), 0, 0)
        }

        val nativeBtn = buildActionPill("Native UI") {
            closeExpandedQuickPanel()
            openNativeSystemVolumeUI()
        }

        val shotBtn = buildActionPill("📸 Stealth Shot") {
            closeExpandedQuickPanel()
            performStealthScreenshot()
        }

        val lockBtn = buildActionPill(
            if (prefs.isPositionLocked) "🔒 Locked" else "🔓 Draggable"
        ) { btn ->
            prefs.isPositionLocked = !prefs.isPositionLocked
            btn.text = if (prefs.isPositionLocked) "🔒 Locked" else "🔓 Draggable"
            triggerHaptic()
        }

        val closeBtn = buildActionPill("✕") {
            closeExpandedQuickPanel()
        }

        actionsRow.addView(nativeBtn)
        actionsRow.addView(shotBtn)
        actionsRow.addView(lockBtn)
        actionsRow.addView(closeBtn)
        panel.addView(actionsRow)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val panelParams = WindowManager.LayoutParams(
            dpToPx(290),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        windowManager.addView(panel, panelParams)
        expandedPanelView = panel
    }

    private fun buildStreamSlider(label: String, streamType: Int): View {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dpToPx(4), 0, dpToPx(4))
        }
        val maxVol = audioManager.getStreamMaxVolume(streamType)
        val curVol = audioManager.getStreamVolume(streamType)

        val title = TextView(this).apply {
            text = "$label: ${(curVol * 100) / maxVol.coerceAtLeast(1)}%"
            textSize = 12f
            setTextColor(Color.WHITE)
        }

        val seekBar = SeekBar(this).apply {
            max = maxVol
            progress = curVol
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        audioManager.setStreamVolume(streamType, progress, 0)
                        title.text = "$label: ${(progress * 100) / maxVol.coerceAtLeast(1)}%"
                        updateBubbleIcon()
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }

        wrapper.addView(title)
        wrapper.addView(seekBar)
        return wrapper
    }

    private fun buildActionPill(textLabel: String, onClick: (TextView) -> Unit): TextView {
        return TextView(this).apply {
            text = textLabel
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(dpToPx(8), dpToPx(6), dpToPx(8), dpToPx(6))
            background = GradientDrawable().apply {
                cornerRadius = dpToPx(12).toFloat()
                setColor(Color.parseColor("#334155"))
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dpToPx(5)
            }
            layoutParams = lp
            setOnClickListener { onClick(this) }
        }
    }

    private fun closeExpandedQuickPanel() {
        expandedPanelView?.let {
            windowManager.removeView(it)
            expandedPanelView = null
        }
        scheduleAutoDim()
    }

    private fun snapToNearestHorizontalEdge() {
        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val targetX = if (bubbleParams.x + (bubbleParams.width / 2) < screenWidth / 2) {
            0
        } else {
            screenWidth - bubbleParams.width
        }

        ValueAnimator.ofInt(bubbleParams.x, targetX).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                bubbleParams.x = anim.animatedValue as Int
                floatingBubbleView?.let { windowManager.updateViewLayout(it, bubbleParams) }
            }
            start()
        }
        prefs.savedX = targetX
        prefs.savedY = bubbleParams.y
    }

    private fun applyDynamicPreferences() {
        val view = floatingBubbleView ?: return
        val newSize = dpToPx(prefs.buttonSizeDp)
        bubbleParams.width = newSize
        bubbleParams.height = newSize
        windowManager.updateViewLayout(view, bubbleParams)
        wakeUpBubbleOpacity()
        scheduleAutoDim()
    }

    private fun wakeUpBubbleOpacity() {
        mainHandler.removeCallbacks(autoDimRunnable)
        floatingBubbleView?.animate()?.alpha(1.0f)?.setDuration(120)?.start()
    }

    private fun scheduleAutoDim() {
        mainHandler.removeCallbacks(autoDimRunnable)
        if (prefs.isAutoDimEnabled) {
            mainHandler.postDelayed(autoDimRunnable, AUTO_DIM_DELAY_MS)
        }
    }

    private fun updateBubbleIcon() {
        bubbleIconText?.text = getVolumeStateEmoji()
    }

    private fun getVolumeStateEmoji(): String {
        val vol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        return when {
            vol == 0 -> "🔇"
            vol < audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 2 -> "🔉"
            else -> "🔊"
        }
    }

    private fun triggerHaptic() {
        if (!prefs.isHapticEnabled) return
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        expandedPanelView?.let { windowManager.removeView(it) }
        floatingBubbleView?.let { windowManager.removeView(it) }
        super.onDestroy()
    }
}
