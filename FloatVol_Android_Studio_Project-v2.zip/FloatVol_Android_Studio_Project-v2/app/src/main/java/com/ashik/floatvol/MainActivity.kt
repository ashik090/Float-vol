package com.ashik.floatvol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var statusBanner: TextView
    private lateinit var toggleServiceBtn: Button
    private lateinit var accessibilityBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsManager(this)
        requestNotificationPermissionIfNeeded()
        setContentView(buildDashboardUI())
    }

    override fun onResume() {
        super.onResume()
        updateServiceStatusUI()
    }

    private fun buildDashboardUI(): ScrollView {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B1120"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
        }

        val header = TextView(this).apply {
            text = "FloatVol Controller v1.1"
            textSize = 26f
            setTextColor(Color.WHITE)
        }
        val subtitle = TextView(this).apply {
            text = "Always-on-Top Native Volume + Stealth Screenshot"
            textSize = 14f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, dp(4), 0, dp(20))
        }
        root.addView(header)
        root.addView(subtitle)

        statusBanner = TextView(this).apply {
            textSize = 14f
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = cardBg("#1E293B")
        }
        root.addView(statusBanner)

        toggleServiceBtn = Button(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setOnClickListener { handleServiceToggle() }
        }
        val btnParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(54)
        ).apply {
            topMargin = dp(14)
            bottomMargin = dp(10)
        }
        root.addView(toggleServiceBtn, btnParams)

        accessibilityBtn = Button(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(accessibilityBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ).apply { bottomMargin = dp(10) })

        val testNativeBtn = Button(this).apply {
            text = "Test Phone's Native Volume Menu Now"
            textSize = 14f
            setTextColor(Color.parseColor("#38BDF8"))
            background = cardBg("#172554")
            setOnClickListener {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.adjustSuggestedStreamVolume(
                    AudioManager.ADJUST_SAME,
                    AudioManager.USE_DEFAULT_STREAM_TYPE,
                    AudioManager.FLAG_SHOW_UI
                )
            }
        }
        root.addView(testNativeBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ).apply { bottomMargin = dp(20) })

        val settingsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = cardBg("#1E293B")
        }

        settingsCard.addView(buildSwitchRow(
            "Double-Click Stealth Screenshot",
            "Hides floating button completely before capturing screenshot",
            prefs.isDoubleTapScreenshot
        ) {
            prefs.isDoubleTapScreenshot = it
            notifyServiceRefresh()
        })

        settingsCard.addView(buildSwitchRow(
            "Fix & Lock Button Position",
            "Prevent accidental dragging across the screen",
            prefs.isPositionLocked
        ) {
            prefs.isPositionLocked = it
            notifyServiceRefresh()
        })

        settingsCard.addView(buildSwitchRow(
            "Vertical Swipe Volume Step",
            "When locked, swipe up/down on button to raise/lower volume",
            prefs.isSwipeVolumeEnabled
        ) {
            prefs.isSwipeVolumeEnabled = it
            notifyServiceRefresh()
        })

        settingsCard.addView(buildSwitchRow(
            "Magnetic Edge Snapping",
            "Snap cleanly to left or right screen edge after dragging",
            prefs.isEdgeSnapEnabled
        ) {
            prefs.isEdgeSnapEnabled = it
            notifyServiceRefresh()
        })

        settingsCard.addView(buildSwitchRow(
            "Ghost Auto-Dim When Idle",
            "Fade button opacity after 3 seconds of inactivity",
            prefs.isAutoDimEnabled
        ) {
            prefs.isAutoDimEnabled = it
            notifyServiceRefresh()
        })

        settingsCard.addView(buildSwitchRow(
            "Tactile Haptic Feedback",
            "Subtle vibration pulse on tap, screenshot, and volume step",
            prefs.isHapticEnabled
        ) {
            prefs.isHapticEnabled = it
            notifyServiceRefresh()
        })

        settingsCard.addView(buildSeekBarRow(
            "Floating Button Size",
            "dp",
            36,
            76,
            prefs.buttonSizeDp
        ) {
            prefs.buttonSizeDp = it
            notifyServiceRefresh()
        })

        settingsCard.addView(buildSeekBarRow(
            "Idle Ghost Opacity",
            "%",
            15,
            100,
            prefs.idleOpacityPercent
        ) {
            prefs.idleOpacityPercent = it
            notifyServiceRefresh()
        })

        root.addView(settingsCard)

        val guideCard = TextView(this).apply {
            text = "Gesture Shortcuts:\n" +
                    "• Single Tap: Opens Phone's Native Volume UI\n" +
                    "• Double Tap: Takes Stealth Screenshot (Button is hidden in capture!)\n" +
                    "• Long Press: Opens Multi-Stream Quick Hub (Media, Ring, Alarm, Stealth Shot & Lock)\n" +
                    "• Swipe Up/Down (while locked): Quick Volume Step Up/Down"
            textSize = 13f
            setTextColor(Color.parseColor("#CBD5E1"))
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = cardBg("#0F172A")
        }
        val guideParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(18) }
        root.addView(guideCard, guideParams)

        scroll.addView(root)
        return scroll
    }

    private fun handleServiceToggle() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Please grant 'Appear on top' permission first",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }

        val newState = !prefs.isServiceEnabled
        prefs.isServiceEnabled = newState
        val serviceIntent = Intent(this, FloatingVolumeService::class.java)
        if (newState) {
            ContextCompat.startForegroundService(this, serviceIntent)
        } else {
            stopService(serviceIntent)
        }
        updateServiceStatusUI()
    }

    private fun updateServiceStatusUI() {
        val hasOverlay = Settings.canDrawOverlays(this)
        val hasAccessibility = FloatVolAccessibilityService.instance != null

        if (hasAccessibility) {
            accessibilityBtn.text = "✅ Stealth Screenshot Accessibility Active"
            accessibilityBtn.background = cardBg("#065F46")
        } else {
            accessibilityBtn.text = "📸 Enable Stealth Screenshot Permission"
            accessibilityBtn.background = cardBg("#4F46E5")
        }

        if (!hasOverlay) {
            statusBanner.text = "⚠️ Overlay Permission Required: Tap the button below to enable 'Appear on top'."
            statusBanner.setTextColor(Color.parseColor("#FBBF24"))
            toggleServiceBtn.text = "Grant Overlay Permission"
            toggleServiceBtn.background = cardBg("#D97706")
        } else if (prefs.isServiceEnabled) {
            statusBanner.text = "✅ Floating Volume Button is ACTIVE and fixed on top (0% idle CPU)."
            statusBanner.setTextColor(Color.parseColor("#34D399"))
            toggleServiceBtn.text = "Stop Floating Button"
            toggleServiceBtn.background = cardBg("#DC2626")
        } else {
            statusBanner.text = "⏸️ Floating Volume Button is currently stopped."
            statusBanner.setTextColor(Color.parseColor("#94A3B8"))
            toggleServiceBtn.text = "Start Floating Volume Button"
            toggleServiceBtn.background = cardBg("#0284C7")
        }
    }

    private fun notifyServiceRefresh() {
        if (prefs.isServiceEnabled && Settings.canDrawOverlays(this)) {
            val intent = Intent(this, FloatingVolumeService::class.java).apply {
                action = FloatingVolumeService.ACTION_REFRESH_PREFS
            }
            ContextCompat.startForegroundService(this, intent)
        }
    }

    private fun buildSwitchRow(
        title: String,
        subtitle: String,
        initial: Boolean,
        onChanged: (Boolean) -> Unit
    ): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tView = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        val sView = TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(Color.parseColor("#94A3B8"))
        }
        textCol.addView(tView)
        textCol.addView(sView)

        val sw = Switch(this).apply {
            isChecked = initial
            setOnCheckedChangeListener { _, isChecked -> onChanged(isChecked) }
        }
        row.addView(textCol)
        row.addView(sw)
        return row
    }

    private fun buildSeekBarRow(
        title: String,
        unit: String,
        minVal: Int,
        maxVal: Int,
        currentVal: Int,
        onChanged: (Int) -> Unit
    ): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        val label = TextView(this).apply {
            text = "$title: $currentVal$unit"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        val sb = SeekBar(this).apply {
            max = maxVal - minVal
            progress = (currentVal - minVal).coerceAtLeast(0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = minVal + p
                    label.text = "$title: $v$unit"
                    if (fromUser) onChanged(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(label)
        col.addView(sb)
        return col
    }

    private fun cardBg(hex: String): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.parseColor(hex))
        }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
