package com.ashik.floatvol

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class FloatVolAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: FloatVolAccessibilityService? = null
            private set

        /**
         * Triggers Android's built-in system screenshot action (Android 9.0 / API 28+).
         */
        fun triggerSystemScreenshot(): Boolean {
            val service = instance ?: return false
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                service.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            } else {
                false
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Zero event processing for 0% background CPU and battery impact
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }
}
