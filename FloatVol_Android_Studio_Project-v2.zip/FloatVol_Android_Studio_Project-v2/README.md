# FloatVol v1.1 — Always-on-Top Native Volume + Stealth Screenshot

## What's New in v1.1
- **Double-Click Stealth Screenshot**: Double-tapping the floating button hides the button (`View.GONE`), waits for the next display frame (`Choreographer.postFrameCallback`), triggers Android's native `GLOBAL_ACTION_TAKE_SCREENSHOT` via `FloatVolAccessibilityService`, and smoothly fades the button back in after 650ms. The floating button is **never** visible in your screenshots.
- **240ms Tap Debounce**: Ensures double-tapping never accidentally pops open the volume panel before taking the screenshot.

## How to Get Your Installable `.apk` in 2 Minutes (Without Android Studio)
1. Unzip `FloatVol_Android_Studio_Project-v2.zip` and upload its files to a new GitHub repository.
2. Open the **Actions** tab on GitHub and click **Build FloatVol Android APK** -> **Run workflow**.
3. Download **FloatVol-v1.1-debug-apk** (`app-debug.apk`) and install it on your phone.
